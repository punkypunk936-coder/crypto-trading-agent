
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/push.mts
import { getStore } from "@netlify/blobs";
var push_default = async (req, context) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }
  const expectedToken = Netlify.env.get("DASHBOARD_TOKEN") || "";
  if (expectedToken) {
    const token = req.headers.get("X-Token") || "";
    if (token !== expectedToken) {
      return new Response("Forbidden", { status: 403 });
    }
  }
  const data = await req.json();
  if (!data || !data.state) {
    return new Response("Missing state in payload", { status: 400 });
  }
  const store = getStore({ name: "trading-state", consistency: "strong" });
  await store.setJSON("current-state", data.state);
  if (data.trades && Array.isArray(data.trades)) {
    await store.setJSON("trades", data.trades);
  }
  return new Response(
    JSON.stringify({ ok: true, cycle: data.state.cycle_number || 0 }),
    { headers: { "Content-Type": "application/json" } }
  );
};
var config = {
  path: "/api/push"
};
export {
  config,
  push_default as default
};
