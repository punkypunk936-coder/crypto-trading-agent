
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/state.mts
import { getStore } from "@netlify/blobs";
var state_default = async (req, context) => {
  const store = getStore({ name: "trading-state", consistency: "strong" });
  const stateBlob = await store.get("current-state", { type: "json" });
  const tradesBlob = await store.get("trades", { type: "json" });
  const state = stateBlob || {
    status: "offline",
    last_cycle: null,
    cycle_number: 0,
    portfolio_usd: 0,
    available_usd: 0,
    positions: [],
    signals: {},
    pending_orders: [],
    sentiment: {},
    mode: "unknown"
  };
  const trades = tradesBlob || [];
  const closed = trades.filter(
    (t) => t.exit_price && parseFloat(t.exit_price) > 0
  );
  const pnls = closed.map((t) => parseFloat(t.pnl_usd || 0));
  const wins = pnls.filter((p) => p > 0);
  const losses = pnls.filter((p) => p <= 0);
  const stats = closed.length ? {
    total: closed.length,
    wins: wins.length,
    losses: losses.length,
    win_rate: Math.round(wins.length / closed.length * 1e3) / 10,
    total_pnl: Math.round(pnls.reduce((a, b) => a + b, 0) * 100) / 100,
    avg_win: wins.length ? Math.round(wins.reduce((a, b) => a + b, 0) / wins.length * 100) / 100 : 0,
    avg_loss: losses.length ? Math.round(losses.reduce((a, b) => a + b, 0) / losses.length * 100) / 100 : 0,
    best: pnls.length ? Math.round(Math.max(...pnls) * 100) / 100 : 0,
    worst: pnls.length ? Math.round(Math.min(...pnls) * 100) / 100 : 0
  } : {
    total: 0,
    wins: 0,
    losses: 0,
    win_rate: 0,
    total_pnl: 0,
    avg_win: 0,
    avg_loss: 0,
    best: 0,
    worst: 0
  };
  return new Response(
    JSON.stringify({
      state,
      trades: trades.slice(-50).reverse(),
      stats,
      server_time: (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace("T", " ")
    }),
    { headers: { "Content-Type": "application/json" } }
  );
};
var config = {
  path: "/api/state"
};
export {
  config,
  state_default as default
};
