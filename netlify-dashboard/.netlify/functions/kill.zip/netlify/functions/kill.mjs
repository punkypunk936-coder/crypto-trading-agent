
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/kill.mts
import { getStore } from "@netlify/blobs";
var kill_default = async (req, context) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }
  const expectedToken = Netlify.env.get("DASHBOARD_TOKEN") || "";
  if (expectedToken) {
    const token = req.headers.get("X-Token") || "";
    if (token !== expectedToken) {
      return new Response("Forbidden", { status: 403 });
    }
  }
  const data = await req.json().catch(() => ({}));
  const reason = data.reason || "Dashboard kill switch";
  const store = getStore({ name: "trading-state", consistency: "strong" });
  await store.setJSON("kill-signal", {
    active: true,
    reason,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
  return new Response(
    JSON.stringify({ ok: true, message: "Kill signal set" }),
    { headers: { "Content-Type": "application/json" } }
  );
};
var config = {
  path: "/api/kill"
};
export {
  config,
  kill_default as default
};
